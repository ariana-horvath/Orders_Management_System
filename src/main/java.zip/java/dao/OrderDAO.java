package dao;

import model.Order;

/**
 * The type Order dao.
 * @author Ariana Horvath
 */
public class OrderDAO extends AbstractDAO<Order>{
}
