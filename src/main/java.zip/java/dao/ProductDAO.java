package dao;

import model.Product;

/**
 * The type Product dao.
 * @author Ariana Horvath
 */
public class ProductDAO extends AbstractDAO<Product>{
}
