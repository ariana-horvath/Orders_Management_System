package dao;

import model.Client;

/**
 * The type Client dao.
 * @author Ariana Horvath
 */
public class ClientDAO extends AbstractDAO<Client> {
}
